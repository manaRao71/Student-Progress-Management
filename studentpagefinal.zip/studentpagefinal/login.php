<?php

$host="localhost";
$user="root";
$password="";
$db="student_progress_database";

session_start();


$al=mysqli_connect($host,$user,$password,$db);

if($al===false)
{
	die("connection error");
}


if($_SERVER["REQUEST_METHOD"]=="POST")
{
	$usn=$_POST["usn"];
	$password=$_POST["password"];


	$sql="select * from student_login where usn='".$usn."' AND password='".$password."' ";

	$result=mysqli_query($al,$sql);

	$row=mysqli_fetch_array($result);
	$_SESSION['usn'] =$usn;
	if($row)
	{	

		

		header("location:viewresult1.php");
	}
	else
	{
		echo "username or password incorrect";
	}

}




?> 



<!DOCTYPE html>
<html>
<head>
	<title>shop login</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>

<center>

	<h1>Login Form</h1>
	<br><br><br><br>
	<div style="background-color: grey; width: 500px;">
		<br><br>


		<form action="" method="POST">

	<div>
		<label>usn</label>
		<input type="text" name="usn" required>
	</div>
	<br><br>

	<div>
		<label>password</label>
		<input type="password" name="password" required>
	</div>
	<br><br>

	<div>
		
		<input type="submit" value="Login">
	</div>


	</form>


	<br><br>
 </div>
</center>

</body>
</html>