<?php
error_reporting(0);
$al=mysqli_connect("localhost","root","","student_progress_database");
$usn=$_POST['usn'];
$x=mysqli_query($al,"SELECT * FROM student WHERE usn='$usn'");
$y=mysqli_fetch_array($x);
$sem=$y['sem'];
$sname=$y['sname'];
$branch=$y['branch'];
$a=mysqli_query($al,"SELECT * FROM cie WHERE usn='$usn' AND sem='$sem'");
$b=mysqli_fetch_array($a);
?>
<!DOCTYPE html>
<html lang="en"">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Online Result</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<style>
    table,th,td{
        padding: 20px;
        border: 1px solid black;
        border-collapse: collapse;
        text-align: center;
    }
    .head{
        font-size: 30px;
        padding: 50px;
    }
    button{
      width: 80px;
    background: #0065ff;
    color: #fff;
    border: none;
    outline: none;
    width: 120px;
    padding: 10px 30px;
    border-radius: 5px;
    font-size: 0.85em;
    font-weight: 500;
    margin-top: 5px;
    cursor: pointer;
    
  }
    }
    </style>
</head>

<body><br />

<div align="center">
<span class="head">View Result</span>
<hr class="hr" />
<br />
<br />


<span class="labels"><B>Name :</B> <?php echo $sname;?><br><br><B>USN :</B> <?php echo $usn;?><br><br><B>Semester :</B> <?php echo $sem;?><br><br><B>Branch :</B> <?php echo $branch;?></span>

<br />
<br />
<?php
  $sql="SELECT cid,cname,IA1,IA2,IA3,assignment,final FROM cie WHERE usn='$usn'";
  $result=$al->query($sql);
  $al->close();
?>
<table>
<tr>
  <th>Subcode</th>
  <th>Subname</th>
  <th>IA1</th>
  <th>IA2</th>
  <th>IA3</th>
  <th>Assignment</th>
  <th>Final IA</th> 
</tr>
<?php
 while($rows=$result->fetch_assoc())
 {
?>
 
<tr>
  <td><?php echo $rows['cid'];?></td>
  <td><?php echo $rows['cname'];?></td>
  <td><?php echo $rows['IA1'];?></td>
  <td><?php echo $rows['IA2'];?></td>
  <td><?php echo $rows['IA3'];?></td>
  <td><?php echo $rows['assignment'];?></td>
  <td><?php echo $rows['final'];?></td>
</tr>
<?php
}
?>
</table>
 

<br />
<br />
<a href="faculty.html" class="link">EXIT</a>
<p><i class="fa fa-print fa-2x" aria-hidden="true" style="cursor:pointer" OnClick="CallPrint(this.value)" ></i></p>
<button onclick="window.print()">Print</button>
</div>

</body>
</html>
