<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Faculty</title>
   
    <link rel="stylesheet" href="addstudent.css">
    <div class="wrapper">
        <div class="sidebar">
            <h2>Home</h2>
           
                <a href="addstudent.php">Add Student</a>
                <a href="search.html">Add Marks</a>
                <a href="addfaculty.html">Add Faculty</a>
                <a href="facultycourse.php">Faculty Course Enrollment</a>
                <a href="studentcourse.php">Student Course Enrollment</a>
                <a href="search1.php">View Result</a>
                <a href="adminlogin.html">Logout</a>
        </div>
    
    <div class="main_content">
        <div class="header">Student Progress Management System</div>
    </div>
    <div class="form-container">
        <div class="form-box">
            <h2>Faculty Details</h2>
            <form action="" method="POST">
                <div class="field">
                    <input type="fid" name="fid" placeholder="Fid" required>
                </div>
                <div class="field">
                    <input type="name" name="fname" placeholder="Faculty Name" required>
                </div>
                <div class="field">
                    <input type="department" name="department"placeholder="Department" required>
                    </div>
                <div class="field">
                    <input type="date" name="dob" placeholder="DOB (yyyy/mm/dd)" max="1997-12-31">
                </div>
                <div class="field">
                    <input type="address" name="address" placeholder="Address">
                </div>
                <div class="field">
                    <input type="phone" name="fphone" pattern="^[6 7 8 9]\d{9}$" placeholder="Phone-no">
                </div>
                <div class="field">
                    <input type="email" name="fmail" pattern="^[A-Za-z0-9+_.-]+@(.+)$" placeholder="Email-id">
                </div>
                    <input  class="add-btn" type="submit" name="add" value="Add">
            </form>
        </div>
    </div>
</div>
</head>
<body>
    
</body>
</html>

<?php
$server = "localhost";
$username = "root";
$password = "";
$dbname = "student_progress_database";
$con = new mysqli("localhost","root","","student_progress_database");
if(isset($_POST['add']))
{
        
    $fid =  $_POST['fid'];
    $fname = $_POST['fname'];
    $department =  $_POST['department'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];
    $fphone = $_POST['fphone'];
    $fmail = $_POST['fmail'];
          
    $sql = "INSERT INTO faculty(fid,fname,department,dob,address,fphone,fmail)  VALUES ('$fid', '$fname','$department','$dob','$address','$fphone','$fmail')";
    $run=mysqli_query($con,$sql) or die(mysqli_error());
    echo "<script>
    window.alert('Successfully Added')
    </script>";
}
else
{
    echo "record not inserted";
}
?>