<?php
    $_SESSION['var'] = $_POST['usn'];
    if ( isset($_POST['usn']))
    {
        $usn = $_POST['usn'];
        $con = new mysqli("localhost","root","","student_progress_database");
        if($con->connect_error) 
        {
            die("Failed to connect : ".$con->connect_error);
        } 
        else 
        {
                $stmt = $con->prepare("select * from student where usn = ?");
                $stmt->bind_param("s",$usn);
                $stmt->execute();
                $stmt_result = $stmt->get_result();
                if($stmt_result->num_rows > 0) 
                {
                    $data = $stmt_result->fetch_assoc();
                    if($data['usn'] == $usn) 
                    {
                        
                        echo "<script>window.open('updatestudent1.php?success=Loggedin succuessfully','_self')</script>";
                    }
                    else 
                    {
                        echo "<h2>Invalid usn !!! </h2>";
                    }
                }
                else
                {
                        echo "<h2>Invalid usn!!! </h2>";
                }
        }

    }

    
?>