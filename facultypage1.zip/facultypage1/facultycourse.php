<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Course Enrollment</title>
   
    <link rel="stylesheet" href="addstudent.css">
    <div class="wrapper">
        <div class="sidebar">
            <h2>Home</h2>
           
                <a href="addstudent.php">Add Student</a>
                <a href="search.html">Add Marks</a>
                <a href="addfaculty.php">Add Faculty</a>
                <a href="facultycourse.php">Faculty Course Enrollment</a>
                <a href="studentcourse.php">Student Course Enrollment</a>
                <a href="search1.php">View Result</a>
                <a href="adminlogin.html">Logout</a>
        </div>
    
    <div class="main_content">
        <div class="header">Student Progress Management System</div>
    </div>
    <div class="form-container">
        <div class="form-box">
            <h2>Course Enrollment</h2>
            <form action="" method="POST">
                <div class="field">
                    <input type="fid" name="fid" placeholder="Fid" required>
                </div>
                <div class="field">
                    <input type="cid" name="cid" placeholder="Course ID" required>
                </div>
                <input  class="add-btn" type="submit" name="add" value="Add">
            </form>
        </div>
    </div>
</div>
</head>
<body>
    
</body>
</html>

<?php
$server = "localhost";
$username = "root";
$password = "";
$dbname = "student_progress_database";
$con = new mysqli("localhost","root","","student_progress_database");
if(isset($_POST['add']))
{
        
    $fid =  $_POST['fid'];
    $cid = $_POST['cid'];
          
    $sql = "INSERT INTO handles(fid,cid)  VALUES ('$fid','$cid')";
    $run=mysqli_query($con,$sql) or die(mysqli_error());
    echo "<script>
    window.alert('Successfully Added')
    </script>";
}
else
{
    echo "record not inserted";
}
?>