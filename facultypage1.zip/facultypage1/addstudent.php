<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   
    <link rel="stylesheet" href="addstudent.css">
    <div class="wrapper">
        <div class="sidebar">
            <h2>Home</h2>
           
                <a href="addstudent.php">Add Student</a>
                <a href="search.html">Add Marks</a>
                <a href="addfaculty.php">Add Faculty</a>
                <a href="facultycourse.php">Faculty Course Enrollment</a>
                <a href="studentcourse.php">Student Course Enrollment</a>
                <a href="search1.php">View Result</a>
                <a href="adminlogin.html">Logout</a>
        </div>
    
    <div class="main_content">
        <div class="header">Student Progress Management System</div>
    </div>
    <div class="form-container">
        <div class="form-box">
            <h2>Student Details</h2>
            <form action="" method="POST">
                <div class="field">
                    <input type="usn" name="usn" placeholder="USN" required>
                </div>
                <div class="field">
                    <input type="name" name="sname" placeholder="Full Name" required>
                </div>
                <div class="field">
                    <input type="branch" name="branch"placeholder="Branch" required>
                    </div>
                <div class="field">
                    <input type="sem" name="sem" placeholder="Sem">
                </div>
                <div class="field">
                    <input type="sec" name="sec" placeholder="Sec">
                </div>
                <div class="field">
                    <input type="date" name="dob" placeholder="DOB (yyyy/mm/dd)" max="2002-12-31">
                </div>
                <div class="field">
                    <input type="address" name="address" placeholder="Address">
                </div>
                <div class="field">
                    <input type="phone" name="sphone" pattern="^[6 7 8 9]\d{9}$" placeholder="Phone-no">
                </div>
                <div class="field">
                    <input type="email" name="smail" pattern="^[A-Za-z0-9+_.-]+@(.+)$" placeholder="Email-id">
                </div>
                
                <input  class="add-btn" type="submit" name="add" value="Add">
            </form>
        </div>
    </div>
</div>
</head>
<body>
    
</body>
</html>

<?php
$server = "localhost";
$username = "root";
$password = "";
$dbname = "student_progress_database";
$con = new mysqli("localhost","root","","student_progress_database");
if(isset($_POST['add']))
{
        
    $usn =  $_POST['usn'];
    $sname = $_POST['sname'];
    $branch =  $_POST['branch'];
    $sem = $_POST['sem'];
    $sec = $_POST['sec'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];
    $sphone = $_POST['sphone'];
    $smail = $_POST['smail'];
          
    $sql = "INSERT INTO student(usn,sname,branch,sem,sec,dob,address,sphone,smail)  VALUES ('$usn', '$sname','$branch','$sem','$sec','$dob','$address','$sphone','$smail')";
    $run=mysqli_query($con,$sql) or die(mysqli_error());
     echo "<script>
     window.alert('Successfully Added')
     </script>";          
}
else
{
    echo "record not inserted";
}
?>