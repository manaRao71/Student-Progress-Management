
<style type="text/css">
    .subdiv{
        padding: 10px;
        margin-left: 160px;
        font-family: 'Poppins', sans-serif;
    }
    .sub{
        justify-content: center;
    align-items: center;
    }
    .back{
        background: #fff;
        border: none;
        outline: none;
        width: 40px;
        padding: 5px 5px;
        font-size: 1.0em;
        font-weight: 500;
        margin-top: 10px;
        cursor: pointer;
     }
     .cl{
        width: 80px;
    background: #0065ff;
    color: #fff;
    border: none;
    outline: none;
    width: 120px;
    padding: 10px 30px;
    border-radius: 5px;
    font-size: 0.85em;
    font-weight: 500;
    margin-top: 5px;
    cursor: pointer;
    }
    body h2{
        font-family: 'Poppins', sans-serif;
    }
</style>

<form method="POST">
    <?php
    $rows = 1;
    if(isset($_GET['number_of_rows'])){
        $rows = $_GET['number_of_rows'];
    }

        for ($i=0; $i < $rows; $i++) { 
            
    ?>
        <body bgcolor="#2148C0">
            <div style="color:#fff">
            <h2 align="center">
                Add Marks.<?=$i+1?>
            </h2>
        </div>
            <div style="margin:20px;background: #fff;border:2px ;padding:20px;width:500px;margin-left: 350px;border-radius: 5px;">
                
                <div class="subdiv">
                    
                <input placeholder="usn" type="text" name='usn<?=$i?>' required>
                </div>
                <div class="subdiv">
                    
                <input type="text" placeholder="sem" name='sem<?=$i?>' required>
                </div>
                <div class="subdiv">
                
                    
                <input type="text" placeholder="cid" name='cid<?=$i?>' required>
                </div>
                <div class="subdiv">
                    
                <input type="text" placeholder="cname" name='cname<?=$i?>' required>
                </div>
                <div class="subdiv">
                    
                <input type="text" placeholder="IA1" name='IA1<?=$i?>' required>
                </div>
                <div class="subdiv">
                    
                <input type="text" placeholder="IA2" name='IA2<?=$i?>' required>
                </div>
                <div class="subdiv">
                    
                <input type="text" placeholder="IA3" name='IA3<?=$i?>' required>
                </div>
                <div class="subdiv">
                    
                <input type="text" placeholder="assignment" name='assignment<?=$i?>' required>
                </div>
                <div class="subdiv">
                    
                <input type="text" placeholder="final" name='final<?=$i?>' >
                </div>
            </div>
            
            <?php
        }
    ?>
    
    <input  type="submit" name="submit">

    </body>  
</form>
<form method="get">
    <input type="number" value="<?=$rows?>" max=10 min="1" name="number_of_rows" required>
    <input type="submit" name="submit2">
    <div class="back">
    <a href="faculty.html">Back</a>
    </div>
</form>

<?php
    function insert_into_db($data){
            foreach($data as $key => $value){
        $k[] = $key;
        $v[] = "'".$value."'";
    }
    $k=implode(",", $k);
    $v=implode(",", $v);

    $conn= mysqli_connect("localhost","root","","student_progress_database");
    $sql="INSERT INTO cie($k) VALUES($v)";
    $run_query=mysqli_query($conn,$sql);

        }
if(isset($_POST['submit'])){
    for ($i=0; $i < $rows ; $i++) { 
        $data=array(
            'usn' => $_POST['usn'.$i],
            'sem' => $_POST['sem'.$i],
            'cid' => $_POST['cid'.$i],
            'cname' => $_POST['cname'.$i],
            'IA1' => $_POST['IA1'.$i],
            'IA2' => $_POST['IA2'.$i],
            'IA3' => $_POST['IA3'.$i],
            'assignment' => $_POST['assignment'.$i],
            'final' => (($_POST['IA1'.$i]+$_POST['IA2'.$i]+$_POST['IA3'.$i])/3)+$_POST['assignment'.$i],
);
        insert_into_db($data);
header("location:updatestudent1.php?row=".$rows);
    }
}
?>
