<?php
error_reporting(0);
$al=mysqli_connect("localhost","root","","student_progress_database");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Login</title>
    <link rel="stylesheet" href="search.css">

</head>
<body>
    <div class="form-container">
        <div class="form-box">
            <h2>Search</h2>
            <form action="viewresult1.php" method="POST">
                <div class="field">
                    <input type="text" name="usn" placeholder="Enter Student USN" required>
                </div>
                
                <input  class="search-btn" type="submit" name="search" value="Search">
            </form>
        </div>
    </div>
    <script>
        //input fields focus effects
        const textInputs = document.querySelectorAll("input");

        textInputs.forEach(textInput => {
            textInput.addEventListener("focus", () => {
                let parent = textInput.parentNode;
                parent.classList.add("active");
            });

            textInput.addEventListener("blur", () => {
                let parent = textInput.parentNode;
                parent.classList.remove("active");
            });
        });
    </script>
</body>
</html>